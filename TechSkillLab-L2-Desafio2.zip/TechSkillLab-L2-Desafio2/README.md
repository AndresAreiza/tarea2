# TechSkillLab-L2-Desafio2
Código base para el desarrollo práctico de la clase #2 y su correspondiente desafío.
